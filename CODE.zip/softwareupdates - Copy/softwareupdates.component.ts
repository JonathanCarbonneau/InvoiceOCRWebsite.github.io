import { Component } from "@angular/core";

@Component ({
    templateUrl: "softwareupdates.component.html",
    styleUrls: ["softwareupdates.component.css"]
})

export class SoftwareupdatesComponent {
    title: string = "Software Updates";

private addition = 100;
private loading = true;
      
public load() {
 
}

}
